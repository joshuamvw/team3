
//Joshua Valentine Williams 816029885
public class LuggageSlip
{
    private Passenger owner;
    private static int luggageSlipIDCounter = 0;
    private String luggageSlipID;
    private String label;

    //Accessors
    
    public Passenger getOwner(){
        return owner;
    }
    
    public int getLuggageSlipIDCounter(){
        return luggageSlipIDCounter;
    }
    
    public String getLuggageSlipID(){
        return luggageSlipID;
    }
    
    public String getLabel(){
        return label;
    }
    
    //Constructor 
    
    public LuggageSlip(Passenger p, Flight f)
    {
        this.owner = p;
        luggageSlipIDCounter += 1;
        this.luggageSlipID = p.getFlightNo() +  "_" + p.getLastName() +  "_" + getLuggageSlipIDCounter();
        this.label = "";
    }

    public LuggageSlip(Passenger p, Flight f, String label)
    {
        // initialise instance variables
        this.owner = p;
        luggageSlipIDCounter += 1;
        this.luggageSlipID = p.getFlightNo() +  "_" + p.getLastName() +  "_" + getLuggageSlipIDCounter();
        this.label = label;
    }
    
    public boolean hasOwner(String passportNumber)
    {
        if(this.owner.getPassportNumber() == passportNumber)
        {
            return true;
        }
        
        return false;
    }
    
    public String toString()
    {
        String information;
        if(getLabel() == "")
        {
            information = getLuggageSlipID() + " " + getOwner().toString();
        }
        else
        {
            information = getLuggageSlipID() + " " + getOwner().toString() + " $" + getLabel();
        }
        return information;
    }
}
