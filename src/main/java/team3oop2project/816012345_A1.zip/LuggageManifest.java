//Joshua Valentine Williams 816029885
import java.util.ArrayList;
public class LuggageManifest 
{
    private ArrayList<LuggageSlip> slips;
    
    //Accessors
    
    private ArrayList<LuggageSlip> getSlips()
    {
        return slips;
    }
    
    //Constructor
    public LuggageManifest()
    {
        slips = new ArrayList<LuggageSlip>();
    }
    
    public String addLuggage(Passenger p, Flight f)
    {
        String output;
        LuggageSlip temp ;
        int numLuggage = p.getNumLuggage();
        double numAllowed = (f.getAllowedLuggage(p.getCabinClass()));
        int numExcess = numLuggage - (int)numAllowed;
        String label;
        
        if(numLuggage == 0)
        {
            output = p.toString() + "\nNo Luggage to add.";
        }
        else
        {
            
            
            if(numExcess <= 0)
            {
                numExcess = 0;
                for(int x = 0; x < numLuggage; x++)
                {
                    temp = new LuggageSlip(p, f);
                    slips.add(temp);
                }
            }
            else{
                label = "" + getExcessLuggageCost(numLuggage, (int)numAllowed);
                for(int x = 0; x < numLuggage; x++)
                {
                    temp = new LuggageSlip(p, f, label);
                    slips.add(temp);
                }
            }

            
            output = p.toString() + "\nPieces Added: (" + numLuggage + ") Excess Cost: " + getExcessLuggageCostByPassenger(p.getPassportNumber());
            
            
        }
        
        return output;
    }
    
    private double getExcessLuggageCost(int numPieces, int numAllowedPieces)
    {
        // put your code here
        double x;
        if(numPieces > numAllowedPieces)
        {
            x = (numPieces - numAllowedPieces) * 35;
        }
        else
        {
            x = 0;
        }
        
        return x;
    }
    
    public String getExcessLuggageCostByPassenger(String passportNumber)
    {
        LuggageSlip slip;
        int luggageCount;
        Passenger tempPassenger;
        char type;
        int numAllowed = 0;
        
        
        int i = 0;
        slip = slips.get(i);
        
        while(i < slips.size() && slip.hasOwner(passportNumber) == false)
        {
            slip = slips.get(i);
            i++;
        }
        tempPassenger = slip.getOwner();
        luggageCount = tempPassenger.getNumLuggage();
        type = tempPassenger.getCabinClass();
        
        //hmmmmm
        if(type == 'F'){
            numAllowed = 3;
        }
        if(type == 'B'){
            numAllowed = 2;
        }
        if(type == 'P'){
            numAllowed = 1;
        }
        if(type == 'E'){
            numAllowed = 0;
        }
        //hmmmmm
        
        
        String output = "$" + getExcessLuggageCost(luggageCount, numAllowed);
        return output;
        
    }
    
    public String toString()
    {
        String information = "LUGGAGE MANIFEST:";
        LuggageSlip temp2;
        
        for(int i = 0; i < this.slips.size() ; i++)
        {
            temp2 = slips.get(i);
            information += "\n";
            information += temp2.toString();
        }
        
        return information;
    }
}
