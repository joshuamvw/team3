//Joshua Valentine Williams 816029885
import java.time.LocalDateTime;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;
public class LuggageManagementSystem
{
    public static void main( String[] args)
    {
        /*  =>  This is simply the test ;3
        LocalDateTime d = LocalDateTime.of(2023, 1, 23, 10, 00, 00);
        Flight yyz = new Flight("BW600", "POS", "YYZ", d);
        
        System.out.println(yyz);
        Passenger p;
        String[] pps = {"TA890789", "BA321963", "LA445241"};
        String[] firstNames = {"Joe", "Lou", "Sid"};
        String[] lastNames = {"Bean", "Deer", "Hart"};
        
        for(int i = 0; i<3; i++)
        {
            p = new Passenger(pps[i], firstNames[i], lastNames[i], "BW600");
            System.out.println(p);
            System.out.println(yyz.checkInLuggage(p));
        }
        System.out.println(yyz.printLuggageManifest());
        */
        String flightNo, destination, origin;
        String passportNumber, firstName, lastName;
        LocalDateTime flightDate;
        //ignore this below
        flightDate = LocalDateTime.of(2023, 1, 1, 10, 00, 00);
        //ignore this above
        int d1, d2, d3, d4, d5, d6, i = 0;
        Scanner myReader, myReader2;
        ArrayList<Flight> yyz = new ArrayList<Flight>();
        Flight tempFlight = new Flight("Just", "Ignore", "This", flightDate);
        
        //Flights reading and printing
        System.out.println("Flights:\n");
        try{
            File inputFlights = new File("Assignment1Flights.txt");
            myReader = new Scanner(inputFlights);
            while (myReader.hasNext()) {
                flightNo = myReader.next();
                destination = myReader.next();
                origin = myReader.next();
                
                d1 = Integer.valueOf(myReader.next());
                d2 = Integer.valueOf(myReader.next());
                d3 = Integer.valueOf(myReader.next());
                d4 = Integer.valueOf(myReader.next());
                d5 = Integer.valueOf(myReader.next());
                d6 = Integer.valueOf(myReader.next());
                
                flightDate = LocalDateTime.of(d1, d2, d3, d4, d5, d6);
                tempFlight = new Flight(flightNo, destination, origin, flightDate);
                yyz.add(tempFlight);
                System.out.println(tempFlight);
                
            }
        }
        catch(FileNotFoundException e)
        {
            System.out.println("An error occurred! Assignment1Flights.txt not found.");
            e.printStackTrace();
        }
        System.out.println("\n");
        
        
        //Passengers reading and printing
        System.out.println("Passengers:\n");
        try{
            File inputPassengers = new File("Assignment1Passengers.txt");
            myReader2 = new Scanner(inputPassengers);
            Passenger p;
            while (myReader2.hasNext()) {
                passportNumber = myReader2.next();
                firstName = myReader2.next();
                lastName = myReader2.next();
                flightNo = myReader2.next();
                
                p = new Passenger(passportNumber, firstName, lastName, flightNo);
                
                for(int x = 0; x < yyz.size(); x++)
                {
                    if(  (yyz.get(x).getFlightNo()).equals(flightNo)  )
                    {
                        tempFlight = yyz.get(x);
                    }
                }
                
                System.out.println(tempFlight.checkInLuggage(p));
            }
        }
        catch(FileNotFoundException e)
        {
            System.out.println("An error occurred! Assignment1Passengers.txt not found.");
            e.printStackTrace();
        }
        System.out.println("\n");
        
        
        //Manifests
        String output;
        
        for(int y = 0 ; y < yyz.size() ; y++)
        {
            // output = "LUGGAGE MANIFEST FOR FLIGHT " + yyz.get(y).getFlightNo() + ":" ;
            // System.out.println(output);
            // System.out.println("\n");
            System.out.println("Flight " + yyz.get(y).getFlightNo() + " " + yyz.get(y).printLuggageManifest());
            System.out.println("\n");
        }
    }
}
