//Joshua Valentine Williams 816029885
import java.time.LocalDateTime;
public class Flight
{
    private String flightNo;
    private String destination;
    private String origin;
    private LocalDateTime flightDate;
    private LuggageManifest manifest;

    //Accessors
    
    public String getFlightNo(){
        return flightNo;
    }
    
    public String getDestination(){
        return destination;
    }
    
    public String getOrigin(){
        return origin;
    }
    
    public LocalDateTime getFlightDate(){
        return flightDate;
    }
    
    public LuggageManifest getManifest(){
        return manifest;
    }
    
    //Constructor
    
    public Flight(String flightNo, String destination, String origin, LocalDateTime flightDate)
    {
        this.flightNo = flightNo;
        this.destination = destination;
        this.origin = origin;
        this.flightDate = flightDate;
        this.manifest = new LuggageManifest();
    }

    public String checkInLuggage(Passenger p)
    {
        String output = "Invalid flight";
        if((this.flightNo).equals(p.getFlightNo()))
        {
           output = this.manifest.addLuggage(p, this);
        }
        
        return output;
    }
    
    public String printLuggageManifest( )
    {
        String output2 = this.manifest.toString();
        return output2;
    }
    
    public int getAllowedLuggage(char cabinClass)
    {
        if(cabinClass == 'F'){
            return 3;
        }
        if(cabinClass == 'B'){
            return 2;
        }
        if(cabinClass == 'P'){
            return 1;
        }
        if(cabinClass == 'E'){
            return 0;
        }
        
        return -1;
    }
    
    public String toString()
    {
        String information = getFlightNo() + " DESTINATION: " + getDestination() + " ORIGIN: " + getOrigin() + " " + getFlightDate();
        return information;
    }
}
